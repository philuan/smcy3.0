<template>
	<div class="search_result">
		
	</div>
</template>
<script>
export default {
  name: '',
  props: [],
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>
<style lang="scss" scoped>

</style>